from django.apps import AppConfig


class OsnovaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'osnova'
